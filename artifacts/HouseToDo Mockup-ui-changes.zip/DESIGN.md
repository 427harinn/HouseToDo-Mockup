# UI Lab Design Context

- Project: HouseToDo Mockup
- Viewport: 390 × 844px

## Tokens

```json
{
  "color": {
    "background": "#fcfbf7",
    "border": "#e5e7e2",
    "calendarSaturday": "#4b8fb4",
    "calendarSunday": "#c86461",
    "disabled": "#c8ccc7",
    "marigold": "#f2c968",
    "primary": "#8fd3b6",
    "primarySoft": "#e7f5ef",
    "primaryStrong": "#4e9f7d",
    "surface": "#ffffff",
    "taskDate": "#78afc7",
    "taskMonth": "#e2be73",
    "taskNoDeadline": "#aeb5af",
    "taskOverdue": "#d96b63",
    "taskWeek": "#8fd3b6",
    "text": "#303531",
    "textSecondary": "#717772",
    "yellowBeige": "#e8ddbe"
  },
  "radius": {
    "action": "10px",
    "input": "8px",
    "sheet": "16px"
  },
  "spacing": {
    "1": "4px",
    "2": "8px",
    "3": "12px",
    "4": "16px",
    "5": "20px",
    "6": "24px",
    "8": "32px"
  }
}
```

## Screens

- calendar: Calendar (/calendar) — states: completed-hidden, date-open, dense, long-text, normal; default: normal
- home: Home (/home) — states: assigned, completed-open, empty, long-text, many, mixed, normal, overdue; default: normal
- shopping: Shopping (/shopping) — states: empty, expanded, long-text, many, normal, photo, purchased-open; default: normal

## Components

- Calendar.DayCell
- Home.TaskRow
- Home.TaskRow.Name
- Shopping.ItemRow

## UI Lab changes

- Calendar.DayCell / 2026-08-20 / calendar / normal: background (exact) #ffffff → #edf7ff
- Home.TaskRow / normal-trash / home / normal: background (exact) #000000 → #eef8f1
- Home.TaskRow / normal-trash / home / normal: position (visual) {"x":20,"y":82.1875} → {"x":22,"y":82.1875}
- Home.TaskRow / normal-trash / home / normal: width (visual) 344 → 340
- Home.TaskRow.Name / home-task-normal-trash-name / home / normal: fontSize (exact) 16 → 18
- Shopping.ItemRow / shopping-milk / shopping / normal: width (visual) 344 → 350

This document describes the intended visual result. IMPLEMENTATION.md describes how to implement it safely within the existing application architecture.

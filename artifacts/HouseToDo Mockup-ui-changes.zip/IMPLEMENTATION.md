# UI Lab Implementation Instructions

## Purpose

This package contains visual changes created in UI Lab so they can be implemented in the real application. It is a Codex implementation package, separate from the '.ui-project' editing-session format.

## Important rules

- Preserve the existing application architecture.
- Respect the existing React, CSS, Flex, Grid, and responsive structure.
- UI Lab raw coordinates are editor-space measurements. Do not automatically implement them as position: absolute; left: ...; top: ...;.
- For each change: inspect the existing component layout, preserve Flex/Grid/responsive behavior, infer spacing/alignment/size changes, implement the smallest source-level change, and compare against the supplied screenshot.
- Only use absolute positioning when the existing UI already requires it.
- exact means use the specified value in the implementation unless the existing design system provides an equivalent token.
- visual means a visual target. Reinterpret it within the existing layout; do not copy raw px coordinates into absolute positioning.
- target means an approximate goal and may be implemented with the closest stable source-level value.
- componentId is the primary implementation target.
- instanceId is a visual reference. An instance-specific override is allowed only when a clear exception is required; do not hard-code a DOM instance merely because UI Lab edited it.
- Preserve behavior and business logic. Do not change unrelated UI.

## Files

- ui-changes.json: normalized, final-state change records sorted by screen, state, component, instance, and property.
- design-tokens.json: the Adapter's semantic token structure, excluding editor transient values.
- screens.json: screen routes, states, and default states from validated Adapter metadata.
- IMPLEMENTATION.md: implementation rules and production-safety guidance.
- DESIGN.md: visual intent and context.
- screenshots/: visual reference images for each changed screen/state.

## Changes

Read ui-changes.json. Resolve each record against the semantic component first. Same-scope records have already been resolved to one final state; do not re-apply stale intermediate values.

## Screenshots

Screenshots are visual references, not source code. Compare GUI changes against the relevant screen/state image after implementation.

## Validation

Run the existing lint, typecheck, unit/integration tests, and build after changes. For GUI changes, use Playwright or an equivalent browser check and compare against the supplied screenshots.

## Production safety

Codex must not delete unrelated application code, rewrite entire components unnecessarily, change API/business logic unless required by the UI change, remove accessibility behavior, remove responsive behavior, or replace the design-system architecture without reason. Use existing design tokens where equivalent, modify shared components for semantic/shared changes, use instance-specific overrides only when explicitly necessary, run existing quality gates, and provide screenshots for GUI changes.

## Export summary

- Project: HouseToDo Mockup
- Changes: 6
- Export formatVersion: 1
